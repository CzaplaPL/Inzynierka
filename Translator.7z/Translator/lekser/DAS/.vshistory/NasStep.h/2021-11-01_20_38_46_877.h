#pragma once
#include <string>
#include <vector>

#include "MachineStep.h"
#include "StepInDas.h"

using namespace std;
class NasStep
{
	vector<StepInDas> dasSteps;
public:
	NasStep(vector<StepInDas> dasSteps);
};
