#include "StepInDas.h"

StepInDas::StepInDas(int dasId, std::string stepId)
{
	this->stepId = stepId;
	this->dasId = dasId;
}