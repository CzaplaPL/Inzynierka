#include "DasService.h"
#include "NasStep.h"
#include "StepInDas.h"

Lekser DasServices::generateLekser(vector<pair<string, string>> elements)
{
	vector < Das > Dases;
	for (pair<string, string> element : elements)
	{
		int id = 0;
		RegexNode* tree = this->regexService.generateTree(element.second, id);
		Dases.emplace_back(this->dasBuilder.generateDas(tree, element.first));
	}
	Das lekserMachine = mergeDases(Dases);
	return Lekser();
}

Das DasServices::mergeDases(vector<Das>& dases)
{
	this->idCreator.clearMap();
	vector<StepInDas> firstSteps;
	queue<NasStep> indefiniteSteps;

	for (int i = 0; i < dases.size(); ++i)
	{
		firstSteps.emplace_back(i, dases[i].getFirstStepId());
	}

	indefiniteSteps.push(NasStep(firstSteps));

	while (indefiniteSteps.size() > 0)
	{
		NasStep indefiniteStep = indefiniteSteps.front();
		indefiniteSteps.pop();
		for (StepInDas step : indefiniteStep.getSteps())
		{
			MachineStep dasStep = dases[step.getDasId()].getStep(step.getId());
			//vector<string> followPosition = dasStep;
		}
	}

	return  Das("dupa");
}