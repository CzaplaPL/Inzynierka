#pragma once
#ifdef LEKSER
#define LEKSER __declspec(dllexport)
#else
#define LEKSER __declspec(dllimport)
#endif

#include"addons/LoggerInterface.h"
#include"addons/Logger.h"

class Lekser
{
	ILogger* log;

public:
	Lekser();
	Lekser(ILogger* log);
};