#pragma once
#include <string>
#include <vector>

#include "MachineStep.h"
#include "StepInDas.h"

using namespace std;
class NasStep
{
	vector<StepInDas> dasSteps;
	map<string, StepInDas> transitions;
public:
	NasStep(vector<StepInDas> dasSteps);

	vector<StepInDas> getSteps()
	{
		return this->dasSteps;
	}
};
