#pragma once
#include"addons/LoggerInterface.h"
#include"addons/Logger.h"

class Lekser
{
	ILogger* log;

public:
	Lekser();
	Lekser(ILogger* log);
};