#pragma once
#include <iostream>
using namespace std;
class pointerTest
{
public:
	int DoIt(float a, char b, char c) { cout << "TMyClass::DoIt" << endl; return a + b + c; };
	int DoMore(float a, char b, char c) const
	{
		cout << "TMyClass::DoMore" << endl; return a - b + c;
	};
};
