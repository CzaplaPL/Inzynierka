#pragma once
#include "../Translator/lekser/regex/RegexNode.h"
#include "../Translator/addons/Logger.h"
#include "../Translator/addons/RegexException.h"
#include "PreviewElement.h"

class RegexConstructorSyntaxTree
{
	Logger* logger;
public:

	RegexConstructorSyntaxTree(Logger* logger)
	{
		this->logger = logger;
	}
	//protected:
	//	void (RegexConstructorSyntaxTree::* checkAction(char& regexChar))(char& firstChar, char& secondChar, RegexNode* tree);
	//	void addOr(char& firstChar, char& secondChar, RegexNode* tree);
};
