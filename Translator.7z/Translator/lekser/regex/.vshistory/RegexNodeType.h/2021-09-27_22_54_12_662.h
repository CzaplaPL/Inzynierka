#pragma once

enum class RegexNodeType
{
	ID,
	BLOCK,
	OR,
	STAR,
	PLUS,
	QUESTION,
	COMBINE,
};