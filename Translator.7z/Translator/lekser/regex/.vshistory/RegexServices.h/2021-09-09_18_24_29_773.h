#pragma once
#include "../Translator/lekser/regex/RegexNode.h"
#include "../Translator/addons/Logger.h"

class RegexServices
{
	Logger* logger;
public:

	RegexServices(Logger& logger)
	{
		this->logger = &logger;
	}

	RegexNode* generateTree(std::string& reg);
};
