#include "LekserConfigReader.h"

#include <iostream>

LekserConfigReader::LekserConfigReader(Logger& log)
{
	this->log = &log;
}

bool LekserConfigReader::readConfig(fstream& file)
{
	string line;
	while (getline(file, line))
	{
		cout << line << endl;;
	}
	return true;
}