#include "RegexService.h"

RegexNode* RegexService::generateTree(std::string& reg)
{
	this->logger->debug("budowanie drzewa rozk�adu");

	RegexNode* tree = new RegexNode;
	RegexNode* (RegexConstructorSyntaxTree:: * action)(PreviewElement previewElement, char& curentElement, RegexNode*) = NULL;
	int i = 0;
	if (reg[0] == '(')
	{
		this->logger->debug("zaczynam od nawiasu");
		reg.erase(reg.front(), 1);
		tree->setFirstChild(this->generateTree(reg));
	}
	//todo [] operator

	PreviewElement previewElement = PreviewElement(reg[0]);
	tree->setType(previewElement.type);
	tree->setValue(reg[0]);
	this->logger->debug(previewElement.toString());

	for (; i < reg.length(); ++i)
	{
		this->logger->debug("znak nr " + std::to_string(i));
		this->logger->info(tree->toString());
		try
		{
			if (reg[i] == '\\')i += 1;
			if (reg[i] == '(')
			{
				//todo
				continue;
			}
			switch (previewElement.type)
			{
			case RegexNodeType::OR:
				if (isSpecialChar(reg[i]))throw RegexException("znak specjalny po | jest niedozwolony");
				tree->setSecondChild(RegexNodeType::ID, reg[i]);

				logger->info("dodawanie second child to or");
				break;

			default:
				action = this->checkAction(reg[i]);
				tree = (*this.*action)(previewElement, reg[i], tree);
				break;
			}

			previewElement.setElement(reg[i]);
		}
		catch (std::out_of_range& exception)
		{
			logger->error("b��d podczas tworzenia regexTree");
			if (i == reg.length() - 1)
				logger->error("b��dne zako�czenie regexa");
			logger->error(exception.what());
			logger->debug(reg);
		}
		catch (RegexException exception)
		{
			logger->error("b��d podczas tworzeniae regexTree");
			logger->error("b�ad na znaku" + reg[i]);
			logger->error("nr :" + i);
			logger->error(exception.what());
			logger->debug(reg);
			throw RegexException("b��d podczas tworzenia drzewa rozk�adu regexa");
		}
		catch (std::exception& exception)
		{
			logger->error("b��d podczas tworzeniae regexTree");
			logger->error("b�ad na znaku" + reg[i]);
			logger->error("nr :" + i);
			logger->error(exception.what());
			logger->debug(reg);
			throw RegexException("b��d podczas tworzenia drzewa rozk�adu regexa");
		}
	}
	logger->debug("koniec generowania drzewa");
	logger->info(tree->toString());

	return tree;
}

string RegexService::regexNodeTypeToString(RegexNodeType type)
{
	switch (type)
	{
	case RegexNodeType::ID:
		return "ID";
		break;
	case RegexNodeType::BLOCK:
		return "BLOCK";
		break;
	case RegexNodeType::OR:
		return "OR";
		break;
	case RegexNodeType::STAR:
		return "STAR";
		break;
	case RegexNodeType::PLUS:
		return "PLUS";
		break;
	case RegexNodeType::QUESTION:
		return "QUESTION";
		break;
	case RegexNodeType::COMBINE:
		return "COMBINE";
		break;
	default:
		return "nieznany";
	}
}

bool RegexService::isSpecialChar(char value)
{
	if (value == '|' || value == '*')return true;
	return false;
}