#include "MachineStep.h"

MachineStep::MachineStep(const vector<int>& positions)
{
	this->nodes = positions;
}