#pragma once
class Lekser
{
};
