#include "Lekser.h"

Lekser::Lekser()
{
	this->log = new Logger("Lekser");
	this->configReader = LekserConfigReader(this->log);
}

Lekser::Lekser(ILogger* log)
{
	this->log = log;
}