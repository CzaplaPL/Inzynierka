#pragma once
class Outerm
{
};
