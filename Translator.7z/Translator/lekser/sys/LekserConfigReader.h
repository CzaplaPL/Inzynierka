#pragma once
#include <vector>

#include "../Translator/addons/LoggerInterface.h"

class LekserConfigReader
{
	ILogger* log;
	vector<pair<string, string>> readData;
public:
	LekserConfigReader(ILogger& log);
	bool readConfig(fstream& file);
};
