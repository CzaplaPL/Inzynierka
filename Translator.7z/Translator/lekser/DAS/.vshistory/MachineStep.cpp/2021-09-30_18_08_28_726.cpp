#include "MachineStep.h"

MachineStep::MachineStep(map<string, set<int>>& transitions) :transitionsMap(transitions)
{
}