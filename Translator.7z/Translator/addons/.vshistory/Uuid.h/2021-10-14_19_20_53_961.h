﻿#pragma once

class Uuid
{
public:
};
