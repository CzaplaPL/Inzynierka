#include "MachineStep.h"

MachineStep::MachineStep(map<string, set<int>>& transitions)
{
	this->transitions = transitions;
}