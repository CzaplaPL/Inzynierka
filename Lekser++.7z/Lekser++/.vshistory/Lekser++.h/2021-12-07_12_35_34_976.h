#pragma once
#ifdef MATHLIBRARY_EXPORTS
#define MATHLIBRARY_API __declspec(dllexport)
#else
#define MATHLIBRARY_API __declspec(dllimport)
#endif

#include"addons/LoggerInterface.h"
#include"addons/Logger.h"

class Lekser
{
	ILogger* log;

public:
	Lekser();
	Lekser(ILogger* log);
};