#include "Lekser.h"

Lekser::Lekser()
{
	this->log = new Logger("Lekser");
}

Lekser::Lekser(ILogger* log)
{
	this->log = log;
}