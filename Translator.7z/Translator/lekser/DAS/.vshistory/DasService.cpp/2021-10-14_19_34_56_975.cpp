#include "DasService.h"

#include <map>
#include <queue>
#include <set>

#include "MachineStep.h"

//todo logi

Das DasServices::generateDas(RegexNode* tree)
{
	Das toReturn;
	queue<vector<int>> indefiniteStep;
	map<string, MachineStep> machineSteps;
	indefiniteStep.push(this->firstPos(tree));

	while (indefiniteStep.size() > 0)
	{
		vector<int> step = indefiniteStep.front();
		indefiniteStep.pop();
		map<string, set<int>> transitions;

		for (int nodeId : step)
		{
			RegexNode* node = (*tree)[nodeId];
			if (!typeIsIdOrBlock(node))throw LekserException("typ wezla jest inny niz block lub id");
			vector<int> followPosition = followPos(node);
			string value = node->getValueAsString();

			for (int position : followPosition)
			{
				transitions[value].insert(position);
			}
		}
		string stepId = generateId(step);
		machineSteps.insert({ stepId,MachineStep(transitions) });
		for (pair< string, set<int>> transition : transitions)
		{
			vector<int> transitionSteps(transition.second.begin(), transition.second.end());
			if (machineSteps.find(generateId(transitionSteps)) == machineSteps.end()) {
				indefiniteStep.push(transitionSteps);
			}
		}
	}

	for (pair< string, MachineStep> el : machineSteps)
	{
		int c = 0;
	}
	return toReturn;
}

string DasServices::generateId(const vector<int>& vector)
{
	string toReturn = "";
	for (int element : vector)
	{
		toReturn += to_string(element) + "-";
	}
	return toReturn;
}

bool DasServices::typeIsIdOrBlock(RegexNode* node)
{
	return (node->getType() == RegexNodeType::BLOCK || node->getType() == RegexNodeType::ID);
}