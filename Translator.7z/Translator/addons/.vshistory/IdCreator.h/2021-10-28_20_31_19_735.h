#pragma once
class IdCreator
{
};
