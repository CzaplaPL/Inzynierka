#pragma once
#include"addons/LoggerInterface.h"

class Lekser
{
	ILogger* log;

public:
	Lekser();
	Lekser(ILogger* log);
}