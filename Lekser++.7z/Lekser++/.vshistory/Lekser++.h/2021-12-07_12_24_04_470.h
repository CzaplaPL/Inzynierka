#pragma once
#include"addons/LoggerInterface.h"
#include"addons/Logger.h"

using namespace Lekser;

class Lekser
{
	ILogger* log;

public:
	Lekser();
	Lekser(ILogger* log);
};