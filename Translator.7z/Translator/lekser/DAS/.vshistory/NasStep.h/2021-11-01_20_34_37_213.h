#pragma once
#include <string>
#include <vector>

#include "MachineStep.h"

using namespace std;
class NasStep
{
	vector<pair<int, string>> dasSteps;
	map < string,
public:
	NasStep(vector<pair<int, string>> dasSteps);
};
