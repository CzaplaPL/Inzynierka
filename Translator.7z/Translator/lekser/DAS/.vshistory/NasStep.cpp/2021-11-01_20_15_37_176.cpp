#include "NasStep.h"

void NasStep::addDasStep(MachineStep& machineStep)
{
	if (machineStep.stepIsAccepting())
	{
		this->isAccepting = true;
		this->token = machineStep.getToken();
	}
}