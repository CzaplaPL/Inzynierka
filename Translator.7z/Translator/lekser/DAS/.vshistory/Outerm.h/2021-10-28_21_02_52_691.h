#pragma once
#include <string>
#include <vector>

using namespace std;
class Outerm
{
	vector<pair<int, string>> dasSteps;
	vector<string> symbols;
	string id;
	bool isAccepting;
	string token;
};
