﻿#pragma once
#include <string>
#include <cstdlib>

class Uuid
{
public:
	static std::string generateUUID();
};
