#include "Outerm.h"

void Outerm::addDasStep(MachineStep& machineStep)
{
	if (machineStep.stepIsAccepting())
	{
		this->isAccepting = true;
		this->token = machineStep.getToken();
	}
}