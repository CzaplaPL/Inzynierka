﻿#include "Uuid.h"

std::string Uuid::generateUUID()
{
	const std::string CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
}