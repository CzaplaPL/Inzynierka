#pragma once
#include <string>
#include <vector>

#include "MachineStep.h"

using namespace std;
class Outerm
{
	vector<pair<int, string>> dasSteps;
	set<string> symbols;
	string id;
	bool isAccepting;
	string token;
	void addDasStep(const MachineStep& machine_step);
};
