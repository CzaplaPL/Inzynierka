#include "NasStep.h"

NasStep::NasStep(vector<StepInDas> dasSteps)
{
	this->dasSteps = dasSteps;
}

vector<StepInDas> NasStep::getSteps()
{
}