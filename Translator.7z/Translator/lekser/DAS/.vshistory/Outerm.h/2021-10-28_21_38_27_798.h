#pragma once
#include <string>
#include <vector>
#include <unordered_set>
#include "MachineStep.h"

using namespace std;
class Outerm
{
	vector<pair<int, string>> dasSteps;
	unordered_set<string> symbols;
	string id;
	bool isAccepting;
	string token;
public:
	void addDasStep(const MachineStep& machine_step);
};
