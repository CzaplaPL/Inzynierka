#include "RegexServices.h"

RegexNode RegexServices::generateTree(std::string reg)
{
	return RegexNode();
}
