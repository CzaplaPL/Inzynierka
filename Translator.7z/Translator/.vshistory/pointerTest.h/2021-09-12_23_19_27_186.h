#pragma once
class pointerTest
{
};

