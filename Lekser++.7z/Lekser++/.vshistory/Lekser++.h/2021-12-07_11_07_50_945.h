#pragma once
#include"addons/LoggerInterface.h"
#include"addons/Logger.h"
#include "pch.h"

class Lekser
{
	ILogger* log;

public:
	Lekser();
	Lekser(ILogger* log);
};