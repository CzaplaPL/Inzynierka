#pragma once
class ILogger
{
};