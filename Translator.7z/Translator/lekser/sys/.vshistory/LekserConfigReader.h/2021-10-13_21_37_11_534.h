#pragma once
#include "../Translator/addons/Logger.h"

class LekserConfigReader
{
public:
	LekserConfigReader(Logger& log);
};
