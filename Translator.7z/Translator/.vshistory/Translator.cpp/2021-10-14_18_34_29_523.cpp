﻿#include <iostream>

#include "addons/Logger.h"
<<<<<<< Updated upstream
=======
#include "lekser/DAS/Das.h"
#include "lekser/DAS/DasService.h"
#include "lekser/regex/RegexNode.h"
#include "lekser/regex/RegexService.h"
#include "lekser/sys/LekserConfigReader.h"
>>>>>>> Stashed changes
#define DEBUG true
#define ENV "dev"

int main()
{
	Logger log(ENV);
	log.setDebug(DEBUG);
<<<<<<< Updated upstream
=======
	fstream lekserConfig;
	lekserConfig.open("lekserConfig.leks", ios::in);
	if (!lekserConfig.is_open())log.error("nie udalo się otworzyć lekserConfig.leks");
	LekserConfigReader lekserConfigReader(log);
	lekserConfigReader.readConfig(lekserConfig);
>>>>>>> Stashed changes
	cin.get();
}