#include "RegexConstructorSyntaxTree.h"

//void(RegexConstructorSyntaxTree::* RegexConstructorSyntaxTree::checkAction(
//	char& regexChar))(char& firstChar, char& secondChar, RegexNode* tree)
//{
//	return &addOr;
//}