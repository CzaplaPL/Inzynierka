#include "NasStep.h"

NasStep::NasStep(vector<StepInDas> dasSteps)
{
	this->dasSteps = dasSteps;
}