﻿#pragma once
#include <string>
#include <cstdlib>

class Uuid
{
	const std::string CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
public:
	static std::string generateUUID();
};
