#pragma once
#include <vector>

#include "addons/Logger.h"
#include "lekser/regex/RegexNode.h"

class DasBuilder
{
	Logger* log;
	vector<int> checkFollowPos(RegexNode* parent);
public:
	DasBuilder(Logger& log);

	vector<int> firstPos(RegexNode* tree);
	vector<int> followPos(RegexNode* tree);
	bool nullable(RegexNode* tree);
};
