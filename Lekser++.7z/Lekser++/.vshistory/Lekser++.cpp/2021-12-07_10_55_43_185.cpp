﻿// Lekser++.cpp : Definiuje funkcje biblioteki statycznej.
//

#include "pch.h"
#include "framework.h"

// TODO: To jest przykład funkcji biblioteki
void fnLekser()
{
}
