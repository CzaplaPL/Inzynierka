#pragma once
#include <string>
#include <vector>
#include <unordered_set>
#include "MachineStep.h"

using namespace std;
class Outerm
{
	vector<pair<int, string>> dasSteps;
	SetVector<string> symbols;
	string id;
	bool isAccepting;
	string token;
	void addDasStep(const MachineStep& machine_step);
};
