#pragma once
#include <string>

class StepInDas
{
public:
	int dasId;
	std::string stepId;
	StepInDas(int dasId, std::string stepId);
	int getDasId();
};
