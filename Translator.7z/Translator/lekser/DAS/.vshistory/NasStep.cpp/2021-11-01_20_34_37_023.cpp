#include "NasStep.h"

NasStep::NasStep(vector<pair<int, string>> dasSteps)
{
	this->dasSteps = dasSteps;
}