﻿#include "Uuid.h"

std::string Uuid::generateUUID()
{
}